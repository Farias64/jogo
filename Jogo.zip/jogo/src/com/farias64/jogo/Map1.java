package com.farias64.jogo;

import com.badlogic.gdx.graphics.g2d.*;
import com.farias64.jogo.*;
import com.badlogic.gdx.math.*;
import java.util.*;

public class Map1
{
    public static int[][] map_tiles_0;
    public static int[][] map_tiles_1 = {
        {1,1,1,},
        {5,5,5,},
        {5,5,5,},
        {5,5,5,},
        {5,5,5,0,0,0,3,},
        {5,5,5,0,0,0,3,},
        {5,5,5,0,0,0,3,0,0,0,0,0,0,0,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,},
        {5,5,5,1,1,1,1,1,1,1,1,1,1,1,1,1,5,5,0,0,5,5,0,0,5,5,0,0,5,5,0,0,5,5,},
        {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,5,5,0,0,5,5,0,0,5,5,0,0,5,5,},
        {4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,0,0,5,5,0,0,5,5,0,0,5,5,0,0,5,5,},
        {6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,0,0,5,5,0,0,5,5,0,0,5,5,0,0,5,5,},
    };
    public static int[][] map_tiles_2;

    public static List<Rectangle> positions;
    
    public static void start()
    {
    	
    }

    public static void drawMap(Batch batch)
    {
        positions = new ArrayList<Rectangle>();
        for (int y = 0; y < map_tiles_1.length; y++)
        {
            for (int x = 0; x < map_tiles_1[y].length; x++)
            {
                if (map_tiles_1[y][x] != 0)
                {
                    batch.draw(Tiles.findTileById(map_tiles_1[y][x]), Api.sizeGet(10) * x, Api.sizeGet(10) * ((map_tiles_1.length - y) - 1), Api.sizeGet(10), Api.sizeGet(10));
                    if (map_tiles_1[y][x] == 1)
										{
												positions.add(new Rectangle(Api.sizeGet(10) * x, Api.sizeGet(10) * ((map_tiles_1.length - y) - 1), Api.sizeGet(10), Api.sizeGet(10)));
										}
                }
            }
        }
    }
    
    public static void destroyMap()
    {
        
    }
}
