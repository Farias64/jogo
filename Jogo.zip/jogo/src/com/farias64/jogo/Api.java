package com.farias64.jogo;
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.math.*;

public class Api
{
    public static int screenWidth = Gdx.graphics.getWidth();
    public static int screenHeight = Gdx.graphics.getHeight();
    public static TextureRegion loadTexture(String name, int x, int y, int w, int h)
    {
        return new TextureRegion(new Texture(Gdx.files.internal(name)), x, y, w, h);
    }
    public static float sizeGet(float size)
    {
        return ((976 + 600) / 300) * size;
    }
    public static float sizeGetScreen(float size){
        return ((screenWidth + screenHeight) / 300) * size;
    }
    public static float getW(float size)
    {
        return screenWidth / size;
    }
    public static float getH(float size)
    {
        return screenHeight / size;
    }
    public static float sizeGetW(float size)
    {
        return (screenWidth / 300) * size;
    }
    public static float sizeGetH(float size)
    {
        return (screenHeight / 200) * size;
    }
    public static boolean getColliderTop(Rectangle r1, Rectangle r2)
    {
        if (r1.x + r1.getWidth() > r2.x && r1.x < r2.x + r2.getWidth())
        {
            if (r1.y < r2.y + r2.getHeight() + sizeGet(2) && r1.y > r2.y + (r2.getHeight() - sizeGet(2)))
            {
                return true;
            }
        }
        return false;
    }
    public static boolean getColliderL(Rectangle r1, Rectangle r2)
    {
        if (r1.x + r1.getWidth() > r2.x && r1.x + r1.getWidth() < r2.x + r2.getWidth())
        {
            if (r1.y < r2.y + (r2.getHeight() - sizeGet(3)) && r1.y + r1.getHeight() > r2.y)
            {
                return true;
            }
        }
        return false;
    }
}
