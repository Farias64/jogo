package com.farias64.jogo;

import com.badlogic.gdx.graphics.g2d.*;
import com.farias64.jogo.*;

public class Tiles
{
  public static TextureRegion spr_tiles[];
  public static void start()
  {
    spr_tiles = new TextureRegion[]{
      null,
      /*1 grass*/Api.loadTexture("tiles_1.png", 16,0, 16,16),
      /*2 grass bottom 1*/Api.loadTexture("tiles_1.png", 16,16, 16,16),
      /*3 escada*/Api.loadTexture("tiles_1.png", 16*3,0, 16,16),
      /*4 grass bottom 2*/Api.loadTexture("tiles_1.png", 16,16*2, 16,16),
      /*5 dirt*/Api.loadTexture("tiles_1.png", 0,16, 16,16),
          /*6 terra escura*/Api.loadTexture("tiles_1.png", 0,16*2, 16,16),
    };
  }
  
  public static TextureRegion findTileById(int id)
  {
    return spr_tiles[id];
  }
}
