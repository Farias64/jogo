package com.farias64.jogo;

import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.*;

public class GameHud 
{
    static ImageButton buttonLeft, buttonRight, buttonJump;
    public static void start(Stage stage)
    {
        buttonLeft = new ImageButton(new TextureRegionDrawable(Api.loadTexture("buttons.png", 32, 0, 32, 32)));
        buttonLeft.getImage().setScale(Api.sizeGetScreen(0.6f), Api.sizeGetScreen(0.6f));
        buttonLeft.setColor(1, 1, 1, 0.7f);
        buttonLeft.setPosition(Api.sizeGetScreen(10), Api.sizeGetScreen(10));
        buttonLeft.addListener(new InputListener() {
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button)
            {
                Player.moveLeft();
                buttonLeft.setColor(1, 1, 1, 0.5f);
                return true;
            }

            public void touchUp(InputEvent event, float x, float y, int pointer, int button)
            {
                Player.stop();
                buttonLeft.setColor(1, 1, 1, 0.7f);
            }
        });
        stage.addActor(buttonLeft);

        buttonRight = new ImageButton(new TextureRegionDrawable(Api.loadTexture("buttons.png", 64, 0, 32, 32)));
        buttonRight.getImage().setScale(Api.sizeGetScreen(0.6f), Api.sizeGetScreen(0.6f));
        buttonRight.setColor(1, 1, 1, 0.7f);
        buttonRight.setPosition(Api.sizeGetScreen(30), Api.sizeGetScreen(10));
        buttonRight.addListener(new InputListener() {
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button)
            {
                Player.moveRight();
                buttonRight.setColor(1, 1, 1, 0.5f);
                return true;
            }

            public void touchUp(InputEvent event, float x, float y, int pointer, int button)
            {
                Player.stop();
                buttonRight.setColor(1, 1, 1, 0.7f);
            }
        });
        stage.addActor(buttonRight);

        buttonJump = new ImageButton(new TextureRegionDrawable(Api.loadTexture("buttons.png", 32 * 3, 0, 32, 32)));
        buttonJump.getImage().setScale(Api.sizeGetScreen(0.6f), Api.sizeGetScreen(0.6f));
        buttonJump.setColor(1, 1, 1, 0.7f);
        buttonJump.setPosition(Api.sizeGetScreen(170), Api.sizeGetScreen(10));
        buttonJump.addListener(new InputListener() {
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button)
            {
                if (Player.isChao == true)
                {
                    Player.isJump = true;
                }
                buttonJump.setColor(1, 1, 1, 0.5f);
                return true;
            }

            public void touchUp(InputEvent event, float x, float y, int pointer, int button)
            {
                Player.isJump = false;
                buttonJump.setColor(1, 1, 1, 0.7f);
            }
        });
        stage.addActor(buttonJump);
    }
}
