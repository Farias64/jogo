package com.farias64.jogo;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.math.*;

public class Player
{
	/*Variaveis estaticas*/
	
    public static float x,y;
    public static TextureRegion sprite;
    public static float width, height;
    public static float velX, velY;
    public static Rectangle position;
    public static boolean gravity;
    public static boolean isJump;
    public static boolean isChao;
    
    /*Configuracoes iniciais*/

    public static void start()
    {
        gravity = true;
        isJump = false;
        isChao = false;
        x = Api.sizeGet(50);
        y = Api.sizeGet(70);
        width = Api.sizeGet(10);
        height = Api.sizeGet(10);
        velX = 0;
        velY = 0;
        position = new Rectangle(x, y, width, height);
        sprite = Api.loadTexture("spr_player.png", 0, 0, 16, 16);
    }
    
    /*loop da animacao do player*/

    public static void animation(Batch batch)
    {
        moviment();
        mechanic();
        batch.draw(sprite, x, y, width, height);
    }
    
    /*Movimentos*/

    public static void moviment()
    {
        x += Api.sizeGet(velX);
        y += Api.sizeGet(velY);
        position.x = x;
        position.y = y;
    }
    
    /*Fisica do player*/

    public static void mechanic()
    {
        for (Rectangle r : Map1.positions)
        {
            if (Api.getColliderTop(position, r) == true && isJump == false)
            {
                gravity = false;
                velY = 0;
                y = r.y + r.getHeight();
                isChao = true;
            }
            else if (isJump == false)
            {
                gravity = true;
                isChao = false;
            }
            
            /*if (Api.getColliderL(position, r) == true)
            {
                velX = 0;
                x = r.x - width;
            }*/
        }

        if (gravity == true && velY > -2)
        {
            velY -= 0.2f;
        }
        if (isJump == true)
        {
            if (velY < 3)
            {
                velY += 0.5;
            }
            else
            {
                isJump = false;
            }
        }
    }
    
    /*Movimentos fundamentais*/

    public static boolean moveLeft()
    {
        velX = -1;
        return true;
    }

    public static boolean moveRight()
    {
        velX = 1;
        return true;
    }

    public static void stop()
    {
        velX = 0;
    }
}
