package com.farias64.jogo;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.*;

public class Camera extends OrthographicCamera
{
	public Camera()
	{
		super();
	}
	
	public void configureCamera()
    {
        float size = 800;
        if (Gdx.graphics.getHeight() < Gdx.graphics.getWidth())
            this.setToOrtho(false, size, size * Gdx.graphics.getHeight() / Gdx.graphics.getWidth());
        else
            this.setToOrtho(false, size * Gdx.graphics.getWidth() / Gdx.graphics.getHeight(), size);
    }
}
