/** Automatically generated file. DO NOT MODIFY */
package com.farias64.jogo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}